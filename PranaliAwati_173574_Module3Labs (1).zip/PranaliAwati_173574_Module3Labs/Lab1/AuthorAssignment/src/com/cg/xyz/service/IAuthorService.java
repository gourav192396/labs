package com.cg.xyz.service;

import com.cg.xyz.entities.Author;

public interface IAuthorService {

	void addAuthor(Author author);

	Author findAuthorById(int authorId);

	void removeAuthor(Author author);

	void updateAuthor(Author author);

}
