/* 
 * Lab 1 : Assignment - JPA application to perform CRUD operations (i.e. insert, update, delete) on author entity.
 * Also display the author details based on provided author id.
 */
package com.cg.xyz.client;

import java.util.Scanner;

import com.cg.xyz.entities.Author;
import com.cg.xyz.service.AuthorService;
import com.cg.xyz.service.IAuthorService;

public class Client {
	public static void main(String[] args) {
		Author author = new Author();
		IAuthorService ias = new AuthorService();
		Scanner sc = new Scanner(System.in);
		String choice;
		String firstName,middleName,lastName;
		long phoneNo;
		int authorId;
		while(true) {
			System.out.println("1.Add\n2.Remove\n3.Update\n4.Fetch By Id");
			choice = sc.next();
			switch(choice){
				case "1":
					System.out.println("Enter First name:");
					firstName = sc.next();
					System.out.println("Enter middle name:");
					middleName = sc.next();
					System.out.println("Enter last name:");
					lastName = sc.next();
					System.out.println("Enter mobile number:");
					phoneNo = sc.nextLong();
					author.setFirstName(firstName);
					author.setMiddleName(middleName);
					author.setLastName(lastName);
					author.setMobileNo(phoneNo);
					//pass author object to service
					ias.addAuthor(author);
					break;
				case "2":
					System.out.println("Enter Id:");
					authorId = sc.nextInt();
					// fetch author by id and remove if present
					Author authorToBeRemoved = ias.findAuthorById(authorId);
					if(authorToBeRemoved != null){
						ias.removeAuthor(ias.findAuthorById(authorId));
					} else {
						System.out.println("No record found!");
					}
					break;
				case "3":
					System.out.println("Enter Id:");
					authorId = sc.nextInt();
					Author authorToBeUpdated = ias.findAuthorById(authorId);
					if(authorToBeUpdated != null){
						Author auth = ias.findAuthorById(authorId);
						// update author details to following
						auth.setFirstName("Pranali");
						auth.setMiddleName("A");
						auth.setLastName("Awati");
						auth.setMobileNo(7083335);
						ias.updateAuthor(auth);
					} else {
						System.out.println("No record found!");
					}
					break;
				case "4":
					System.out.println("Enter Id:");
					authorId = sc.nextInt();
					Author fetchedAuthor = ias.findAuthorById(authorId);
					if(fetchedAuthor != null){
						System.out.println(fetchedAuthor);
					} else {
						System.out.println("No record found!");
					}
					break;
			}
		}
	}
}
