package com.cg.xyz.dao;

import com.cg.xyz.entities.Author;

public interface IAuthorDao {
	public abstract void addAuthor(Author author);

	public abstract void removeAuthor(Author author);

	public abstract void updateAuthor(Author author);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

	public abstract Author findAuthorById(int authorId);
}
