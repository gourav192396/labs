package com.cg.xyz.dao;

import javax.persistence.EntityManager;

import com.cg.xyz.entities.Author;



public class AuthorDao implements IAuthorDao {
	private EntityManager entityManager;

	public AuthorDao() {
		entityManager = JPAUtil.getEntityManager();
	}
	@Override
	public void addAuthor(Author author) {
		entityManager.merge(author);
	}

	@Override
	public void removeAuthor(Author author) {
		entityManager.remove(author);
	}

	@Override
	public void updateAuthor(Author author) {
		entityManager.merge(author);
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
	@Override
	public Author findAuthorById(int authorId) {
		// find and return author by uding Id
		Author  auth = entityManager.find(Author.class, authorId);
		return auth;
	}

}
