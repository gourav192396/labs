package com.cg.xyz.service;

import com.cg.xyz.dao.AuthorDao;
import com.cg.xyz.dao.IAuthorDao;
import com.cg.xyz.entities.Author;

public class AuthorService implements IAuthorService {

	IAuthorDao iad;
	
	public AuthorService() {
		iad = new AuthorDao();
	}
	
	@Override
	public void addAuthor(Author author) {
		iad.beginTransaction();
		iad.addAuthor(author);
		iad.commitTransaction();
	}

	@Override
	public Author findAuthorById(int authorId) {
		return iad.findAuthorById(authorId);
	}

	@Override
	public void removeAuthor(Author author) {
		iad.beginTransaction();
		iad.removeAuthor(author);
		iad.commitTransaction();
	}

	@Override
	public void updateAuthor(Author author) {
		iad.beginTransaction();
		iad.updateAuthor(author);
		iad.commitTransaction();
	}

}
