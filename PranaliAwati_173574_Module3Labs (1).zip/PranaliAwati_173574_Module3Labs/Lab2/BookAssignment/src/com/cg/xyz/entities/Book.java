package com.cg.xyz.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="books_Details")
public class Book {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="book_ISBN",length=20)
	private Long bookIsbn;
	@Column(name="book_title",length=20)
	private String bookTitle;
	@Column(name="book_price",length=20)
	double bookPrice;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="books")
	private Set<Author> authors = new HashSet<Author>();


	@Override
	public String toString() {
		return "Book [bookIsbn=" + bookIsbn + ", bookTitle=" + bookTitle
				+ ", bookPrice=" + bookPrice + " ";
	}
	public Long getBookIsbn() {
		return bookIsbn;
	}
	public void setBookIsbn(Long bookIsbn) {
		this.bookIsbn = bookIsbn;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public Set<Author> getAuthor() {
		return authors;
	}
	public void setAuthor(Set<Author> authors) {
		this.authors = authors;
	}
}
