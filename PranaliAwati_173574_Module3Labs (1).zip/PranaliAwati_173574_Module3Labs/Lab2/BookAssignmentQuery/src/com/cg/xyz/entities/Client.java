/*
 * Lab2 - Assignment 2: Program demonstrates many to many association between book and author using queries
 */
package com.cg.xyz.entities;

import java.util.ArrayList;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();

//		 Book book1 = new Book();
//		 book1.setBookIsbn(123L);
//		 book1.setBookTitle("The Alchemist");
//		 book1.setBookPrice(129);
//		
//		 Author auth = new Author();
//		 auth.setAuthorId(1);
//		 auth.setAuthorName("Paulo Coehlo");
//		 auth.addBook(book1);
//		 
//		 Book book2 = new Book();
//		 book2.setBookIsbn(124L);
//		 book2.setBookTitle("The Donor");
//		 book2.setBookPrice(146);
//
//		
//		 Author auth2 = new Author();
//		 auth2.setAuthorId(2);
//		 auth2.setAuthorName("David McMiller");
//		
//		 
//		 auth2.addBook(book2);
//		
//		
//		 em.persist(auth);
//		 em.persist(auth2);
		 
			// get all books
			System.out.println("\nList of books");
			ArrayList<Book> list = (ArrayList<Book>) em.createQuery("SELECT book FROM Book book").getResultList();
			for (Book book : list) {
				System.out.println(book);
			}
			
			// get author for author id 2
			System.out.println("\nAuthor with author Id 2");
			Author author = em.createQuery(
					"SELECT auth FROM Author auth WHERE auth.authorId=2", Author.class)
					.getSingleResult();
			Set<Book> bookList = author.getBooks();
			for (Book book : bookList) {
				System.out.println(book);
			}

			// get author for book isbn 123
			System.out.println("\nBook with book isbn 123");
			Book book = em.createQuery(
					"SELECT bk FROM Book bk WHERE bk.bookIsbn=123", Book.class)
					.getSingleResult();
			Set<Author> authorList = book.getAuthors();
			for (Author author2 : authorList) {
				System.out.println(author2);

			}
			//  get book within range of 140 - 200
			System.out.println("\nBook within range of 140-200");
			ArrayList<Book> priceList = (ArrayList<Book>) em.createQuery(
							"SELECT book FROM Book book WHERE book_price BETWEEN 140 AND 200").getResultList();
			for (Book book1 : priceList) {
				System.out.println(book1);
			}
		 
		 em.getTransaction().commit();
		 em.close();
		 factory.close();

	}

}
