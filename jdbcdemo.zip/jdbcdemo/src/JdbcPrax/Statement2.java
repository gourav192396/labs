package JdbcPrax;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


	public class Statement2 {
		public static void main(String[] args) {
			
			String url="";
			String sql="insert into person values('Polo','21','Pune')";
			Connection conn=null;
			
			try {
				
				conn=JdbcFactory
				//Instantiating oracle driver object
				OracleDriver driver=new OraDriver();
				
				//registerinbg oracle driver with driver mang=ager
				DriverManager.registerDriver(driver);
				
				//Requsting connection from driver manager
				conn=DriverManager.getConnection(url,"gourav","oracle");
				System.out.println("Connectioin succesful...");
			} catch (SQLException e) {
				System.out.println("connectiuon failed due to...");
				e.printStackTrace();
			}finally{
				if(conn != null)
					conn.close();
			}

		}
	}
}
