package JdbcPrax;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonDaoImpl implements PersonDao {
	
	@Override
	public void save(Person P) {
		String sql="insert into person values(?,?,?)";
		Connection conn=null;
		
		try {
			conn=JdbcFactory.getConnection();
			PreparedStatement stmt=conn.prepareStatement(sql);
			
			stmt.setString(1, args[0]);
			stmt.setInt(2,Integer.parseInt(args[1]));
			stmt.setString(3, args[2]);
			
			stmt.executeUpdate();
			System.out.println("Record inserted...");
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(conn !=null)
				try{
					conn.close();
				}catch(SQLException){
					e.printStackTrace();
				}
		}		
		
	}
	@Override
	public List<Person> fetch() {
		String sql="select*from person";
		Connection conn=null;
		List<Person> persons=new ArrayList<>();
		
		try {
			conn=JdbcFactory.getConnection();
			Statement stmt=conn.CreateStatement(sql);
			ResultSet rs=stmt.executeQuery(sql);
			ResultSetMetaData meta=rs.getMetaData();
			System.out.println(meta.getColumnName(1)+"\t"+meta.getColumnLabel(2)+"\t"+meta.getColumnClassName(3));
			
			while(rs.next()){
				Person p=new Person();
				p.setName(rs.getString(1));
				p.setAge(rs.getInt(2));
				p.setCity(rs.getString(3));
				
				persons.add(p);
			}return persons;
		
				System.out.println(rs.getString(1)+ "\t" + rs.getInt("age")+"\t"+rs.getString(3));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}finally{
			if(conn !=null)
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
		}

		
	}
	
}
