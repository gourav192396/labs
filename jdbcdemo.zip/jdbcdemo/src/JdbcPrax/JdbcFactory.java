package JdbcPrax;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.OracleDriver;

public final class JdbcFactory {
private JdbcFactory(){
	
}
public static Connection getConnection() throws SQLException{
	String url="";
	Connection conn=null;
	
	//Instantiating oracle driver object
	OracleDriver driver=new OracleDriver();
	
	//registerinbg oracle driver with driver mang=ager
	DriverManager.registerDriver(driver);
	
	//Requsting connection from driver manager
	conn=DriverManager.getConnection(url,"gourav","oracle");
	return conn; //returning connection object
}
}
