package JdbcPrax;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultDemo {
public static void main(String[] args) {
	String sql="select*from person";
	Connection conn=null;
	
	try {
		conn=JdbcFactory.getConnection();
		Statement stmt=conn.CreateStatement(sql);
		ResultSet rs=stmt.executeQuery(sql);
		ResultSetMetaData meta=rs.getMetaData();
		System.out.println(meta.getColumnName(1)+"\t"+meta.getColumnLabel(2)+"\t"+meta.getColumnClassName(3));
		
		while(rs.next())
			System.out.println(rs.getString(1)+ "\t" + rs.getInt("age")+"\t"+rs.getString(3));
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		if(conn !=null)
			try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
	}


}
}
