package com.capgemini.xyz.bean;
public class Employee {
private String name;
private int id;
private double salary;
private String designation;
String insurance;

public String getInsurance() {
	return insurance;
}
public void setInsurance(String insurance) {
	this.insurance = insurance;
}
public Employee() {
}
public Employee(int id,String name, double salary, String designation) {
	this.id=id;
	this.name = name;
	this.salary = salary;
	this.designation = designation;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
@Override
public String toString() {
	return "Name : " + name + "\nID : " + id + "\nSalary : " + salary
			+ "\nDesignation : " + designation + "\nScheme : "+insurance;
}
@Override
public boolean equals(Object obj) {
	if(obj instanceof Employee)
		return ((Employee)obj).id==id;
		else return false;
}

}
