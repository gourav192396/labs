package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Employee;
import com.capgemini.xyz.service.ValidateUserInput;

public class ExecutorMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String ch;
		String name;
		String salary;
		boolean isValid;
		ValidateUserInput userInput = new ValidateUserInput();
		while (true) {
			while (true) {
				System.out
						.println("1.	Employee Registration\n2.	See Details\n3.	Exit");
				ch = sc.next();
				isValid = userInput.validateChoice(ch);
				if (isValid)
					break;
				else
					System.out.println("Please enter 1 or 2");
			}
			switch (ch) {
			case "1":
				while (true) {

					System.out.println("Enter name");
					name = sc.next();

					// to validate UserName
					isValid = userInput.validateUserName(name);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
				}
				while (true) {

					System.out.println("Enter salary");
					salary = sc.next();
					// to validate user Mobile No
					isValid = userInput.validateSalary(salary);
					if (isValid)
						break;// if user enter valid input then break
					else
						System.out
								.println("Please enter proper Salary (eg. 15000)");

				}
				Employee emp = new Employee();
				emp.setName(name);
				emp.setSalary(Double.parseDouble(salary));
				userInput.storeToList(emp);

				break;
			case "2":
				String id;
				while (true) {
					System.out.println("Enter Id to see details");
					id = sc.next();
					isValid = userInput.validateId(id);
					if (isValid)
						break;// if user enter valid input then break
					else
						System.out.println("Enter Valid id");
				}
				System.out.println(userInput.showDetails(Integer.parseInt(id)));
				break;
			case "3":
				System.exit(0);
			default:
				break;
			}
		}
	}
}
