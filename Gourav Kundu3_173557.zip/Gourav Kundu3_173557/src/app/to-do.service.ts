import { Injectable } from '@angular/core';
import{Router} from '@angular/router';
import { EmployeeModel } from './models/EmployeeModel';

@Injectable({
  providedIn: 'root'
})
export class ToDoService {
  todoArr: EmployeeModel[];

  constructor(private routes:Router) {
    this.todoArr=[];
   }
   add(employee: EmployeeModel) {
    employee.todoId = Math.floor(Math.random() * 100);
    this.todoArr.push(employee);
    this.routes.navigate(['/todo']);
  }
  getEmployees() {
    return this.todoArr;
  }
  login(Username:String,  Password:String){
    
  }

  

  edit(id: number) {
    return this.todoArr.find(x => x.todoId == id);
  }
   
  
  delete(index: number) {
    this.todoArr.splice(index, 1);
  }
  


 

  
}
