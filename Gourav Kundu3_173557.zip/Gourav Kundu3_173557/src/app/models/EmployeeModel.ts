export class EmployeeModel{

    public todoId:number;
    public employeeName:String;
    public task:String;
    
    

}