import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../models/EmployeeModel';
import { ToDoService } from '../to-do.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  todoArr:EmployeeModel[];
  todoToEdit:EmployeeModel;
  isEditing:boolean;

  todoSearched: EmployeeModel;

  constructor(private todoService:ToDoService) { 

    this.todoSearched=new EmployeeModel();
    this.todoToEdit=new EmployeeModel();
    this.todoArr=[]
  }

  ngOnInit() {
    this.todoArr=this.todoService.getEmployees();
  }

    delete(index : number) {
      this.todoService.delete(index);
     }
   
     edit(id:number)
     {
       this.isEditing = true;
       this.todoToEdit = this.todoService.edit(id);
     }
    }


