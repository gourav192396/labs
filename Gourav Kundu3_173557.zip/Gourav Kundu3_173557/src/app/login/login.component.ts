import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userid:string;
    password:string;
    tasks:string[];
  submitted: boolean;
  roles: (elementId: string) => HTMLElement;

  
  

 constructor(){
this.tasks=[];

 }
 validate(){
  this.submitted=true;
  this.roles=document.getElementById
  console.log(this.userid+"="+this.password);
}

  ngOnInit() {
  }
  login(){

  }

}
