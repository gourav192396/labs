package com.capgemini.lesson07.mockdemo;

public class User {
String username, password;
}
