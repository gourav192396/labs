package com.cg.pizzaorder.exception;

public class PizzaException extends Exception{

	public PizzaException() {
		super();
	}

	public PizzaException(String message) {
		super(message);
	}

}
