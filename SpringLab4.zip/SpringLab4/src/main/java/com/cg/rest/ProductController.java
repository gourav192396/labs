package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
@RequestMapping("api/ver1")
public class ProductController {

	@Autowired
	private ProductRepo repo;
	
	@GetMapping("/post")
	public ModelAndView showPostView() {
		return new ModelAndView("post", "product", new Product());
	}

	@PostMapping(path = "/add")
	public Product addProduct(@ModelAttribute("product") Product product, Model model) {
		product = repo.saveProduct(product);
		model.addAttribute("result", "Added Successfully");
		return product;
	}

	@GetMapping(path = "/products", produces = "application/json")
	public List<Product> showAllProducts() {
		return repo.getAll();
	}
	
	@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
		org.springframework.web.util.NestedServletException.class,
		org.springframework.orm.jpa.JpaSystemException.class,
		javax.persistence.PersistenceException.class,
		org.hibernate.exception.ConstraintViolationException.class
	})
	public ModelAndView showError()
	{
		return new ModelAndView("error");
	}
}
