package com.capgemini.xyz.dao;

import java.util.List;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Transaction;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.InsufficientBalanceException;

public interface ICustomerDAO {

	Customer createCustomer(Customer customer) throws CustomerExists;

	String withDraw(Customer customer, double amount)	throws InsufficientBalanceException;

	String deposit(Customer customer, double amount) throws CustomerNotFoundException;

	Customer checkUser(String username, String password) throws CustomerNotFoundException;

	List<Transaction> printTransaction(Customer customer);

	Customer isValidUser(String mobileNumber) throws CustomerNotFoundException;
	
	double checkBalance(Customer customer);

	long ids = 10002;
	
	String insertCustomer =
			"insert into dcrcustomer"
			+ "(customerID,name,email,"
			+ "mobileNumber,password,"
			+ "balance)"
			+ " values"
			+ "(?,?,?,?,?,?)";
	
	String insertTransaction = "insert into transaction"
			+ "(tid,mobno,type,amount,balance)"
			+ " values"
			+ "(tid_seq.nextval,?,?,?,?)";
	
	String findUser = "select * from dcrcustomer where mobilenumber=? and password=?";
	
	String getLastestId = "SELECT MAX(customerID)FROM dcrcustomer";
	
	String checkIfUserExists = "SELECT COUNT(customerID) FROM dcrcustomer where mobilenumber=?";
	
	String withDrawMoney = "UPDATE dcrcustomer SET balance=? WHERE customerid=?";
	
	String depositMoney = "UPDATE dcrcustomer SET balance=? WHERE mobilenumber=?";
	
	String findReciever = "select * from dcrcustomer where mobilenumber=?";
	
	String findTransaction = "SELECT * FROM transaction WHERE mobno=?";
}
