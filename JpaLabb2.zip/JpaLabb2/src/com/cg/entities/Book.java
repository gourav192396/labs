package com.cg.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Book2")
public class Book implements Serializable{

	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + bookTitle + ", price=" + bookPrice+"]\n";
	}


	@Id
	private int ISBN;
	
	private String bookTitle;
	
	private int bookPrice;
	

	@ManyToMany(mappedBy="books", fetch=FetchType.LAZY)
	List<Author> authors= new ArrayList();


	public List<Author> getAuthors() {
		return authors;
	}


	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}


	public int getISBN() {
		return ISBN;
	}


	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}


	public String getTitle() {
		return bookTitle;
	}


	public void setTitle(String title) {
		this.bookTitle = title;
	}


	public int getPrice() {
		return bookPrice;
	}


	public void setPrice(int price) {
		this.bookPrice = price;
	}


	
}
