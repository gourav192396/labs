package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.entities.Author;
import com.cg.entities.Book;


public class AuthorDaoImpl implements AuthorDao {

	private EntityManager entityManager;
	List bookDb;
	List authorDb;
	Book book;
	Author author;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public List getAllBooks() {

		bookDb= entityManager.createQuery("SELECT book from Book book", Book.class).getResultList();
		return bookDb;
	}

	@Override
	public List getBooksByAuthorName(String authorName) {

		author= entityManager.createQuery("SELECT author from Author author WHERE author.authorName=:authorName", Author.class).setParameter("authorName", authorName).getSingleResult();
		bookDb=author.getBooks();
//		book=(Book) bookList.get(0);
	
		return bookDb;
	}

	@Override
	public List getBooksByPriceRange() {
		bookDb= entityManager.createQuery("SELECT book from Book book WHERE book.price between 500 and 1000", Book.class).getResultList();
		return bookDb;
	}

	@Override
	public List fetchAuthorsByBookId(int bookId) {
 
		book=entityManager.createQuery("SELECT book from Book book WHERE book.ISBN=:bookId", Book.class).setParameter("bookId", bookId).getSingleResult();		
		authorDb= book.getAuthors();
		
		return authorDb;
	}

	@Override
	public void addAuthor(Author author) {

		entityManager.persist(author);
	}

	

	
	
	
}
