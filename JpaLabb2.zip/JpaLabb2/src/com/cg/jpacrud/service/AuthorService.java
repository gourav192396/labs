package com.cg.jpacrud.service;

import java.util.List;

import com.cg.entities.Author;

public interface AuthorService {

public List getAllBooks();
	
	public List getBooksByAuthorName(String authorName);
	
	public List getBooksByPriceRange();
	
	public List fetchAuthorsByBookId(int bookId);
	
	public void addAuthor(Author author);
	
}
