package com.cg.jpacrud.service;

import java.util.List;

import com.cg.entities.Author;
import com.cg.entities.Book;
import com.cg.jpacrud.dao.AuthorDao;
import com.cg.jpacrud.dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService {

	AuthorDao dao;
	List bookDb;
	Book book;
	List authorDb;
	
	public AuthorServiceImpl() {
      dao= new AuthorDaoImpl();
	}

	@Override
	public List getAllBooks() {
 
		bookDb=dao.getAllBooks();
		return bookDb;
	}

	@Override
	public List getBooksByAuthorName(String authorName) {

		bookDb=dao.getBooksByAuthorName(authorName);
		return bookDb;
	}

	@Override
	public List getBooksByPriceRange() {

		bookDb=dao.getBooksByPriceRange();
		return bookDb;
	}

	@Override
	public List fetchAuthorsByBookId(int bookId) {

		authorDb=dao.fetchAuthorsByBookId(bookId);
		return authorDb;
	}

	@Override
	public void addAuthor(Author author) {
		
		dao.addAuthor(author);
		
	}
	
	

}
