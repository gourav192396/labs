package com.cg.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Author;
import com.cg.entities.Book;
import com.cg.jpacrud.service.AuthorService;
import com.cg.jpacrud.service.AuthorServiceImpl;

public class Client {

	public static void main(String[] args) {
		EntityManager manager;
		AuthorService service;
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		manager = factory.createEntityManager();
		service = new AuthorServiceImpl();
		List<Author> authorDb = new ArrayList<>();
		List<Book> bookDb = new ArrayList<>();
		String authorName;
		int bookId;
		Scanner sc = new Scanner(System.in);

		for (;;) {
			System.out.println("Enter a choice");
			System.out
					.println("1) Fetch All Books");
			System.out.println("\n 2) Fetch Books By Author Name");
			System.out.println("\n 3) Fetch Books By price range");
					System.out.println("\n 4) Search Author by Book id");
			System.out.println("\n 5)Add Author");
			System.out.println("\n 6) Exit");

			Scanner scan = new Scanner(System.in);
			String choice = scan.next();

			switch (choice) {
			case "1":
				bookDb = service.getAllBooks();
				System.out.println(bookDb);

				break;
			case "2":
				System.out.println("Enter author name");
				authorName = sc.next();
				bookDb = service.getBooksByAuthorName(authorName);
				System.out.println(bookDb);
				break;
			case "3":
				bookDb = service.getBooksByPriceRange();
				System.out.println(bookDb);
				break;
			case "4":
				System.out.println("Enter book id: ");
				bookId = sc.nextInt();
				authorDb = service.fetchAuthorsByBookId(bookId);
				System.out.println(authorDb);
				break;
			case "5":
				Book b1 = new Book();
				b1.setISBN(1);
				b1.setTitle("snow white 1");
				b1.setPrice(100);

				Book b2 = new Book();
				b2.setISBN(2);
				b2.setTitle("snow white 2");
				b2.setPrice(290);

				Author author1 = new Author();
				author1.setID(100);
				author1.setName("snow white");
				author1.addBook(b1);
				author1.addBook(b2);
				manager.getTransaction().begin();
				manager.merge(author1);
				manager.getTransaction().commit();
				break;
			case "6":
				System.exit(1);
				break;
			default:
				break;
			}
		}
	}
}
