package com.cg.anno;

import org.springframework.stereotype.Component;

import com.cg.ioc.Sender;
@Component("wap")
public class WhatsAppSender implements Sender {
	
	public WhatsAppSender() {
		System.out.println("WhatsApp Sender is ready");
	}

	public void send(String to, String msg) {
		System.out.println("WhatsApp:" + msg + ",sent to" + to);
	}

}
