package com.cg.ioc;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.cg.ioc.Sender;

public class Producer implements ApplicationContextAware {
	private ApplicationContext ctx;
	public void process(String type,String to,String msg) {
		Sender sender=(Sender) ctx.getBean(type);
		sender.send(to, msg);
	}

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.ctx=applicationContext;
		
	}

}
