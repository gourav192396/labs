package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Producer;



public class TestSender {
	
	@Test
	public void testProcess() {
		//ApplicationContext ctx=new ClassPathXmlApplicationContext("sender.xml");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("annotated.xml");
		Producer p=(Producer) ctx.getBean("prod");
		
		p.process("sms","9820454545","Hello There");
		p.process("mail","gku5@gmail.com","Hey There");
		p.process("wap","kisko","Pata nahi");
	}

}
