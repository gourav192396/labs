package com.cg.exception;
/**
 * This is the exception class to express invalid product. 
 * @author gkundu
 * @version1.0
 */
public class InvalidProductException extends Exception{

	public InvalidProductException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidProductException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
