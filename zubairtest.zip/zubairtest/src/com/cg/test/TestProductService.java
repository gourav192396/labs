package com.cg.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import bean.Product;

import com.cg.service.ProductService;
import com.cg.service.ProductServiceImpl;

/**
 * This is the test class for service unit teststing
 * @author gkundu
 *
 */
public class TestProductService {
	private ProductService service;
	
	@Before
	public void init(){
		service=new ProductServiceImpl();
	}
	
	@Test
	public void testAddProduct(){
		Product p=new Product();
		p.setName("iPhone");
		p.setPrice(1000);
		service.addProduct(p);
	}
	@After
	public void flush(){
		service=null;
	}

}
