package com.cg.test;
/**
 * This is the test class for dao unit teststing
 * @author gkundu
 * @version 1.0
 *
 */
public class TestProductDao {

}
