package com.cg.util;

import java.util.HashMap;

import bean.Product;

public class Util {
	public static HashMap<Integer,Product> getMap(){
		HashMap<Integer,Product> map=new HashMap<>();
		
		Product p1=new Product();
		p1.setName("iphone");
		p1.setPrice(1000);
		
		Product p2=new Product();
		p2.setName("galaxy");
		p2.setPrice(2000);
		
		map.put(1, p1);
		map.put(2,p2);
		
		return map;
		
	}

}
