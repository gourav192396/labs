/**
 * 
 */
package com.cg.service;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

import bean.Product;

import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.dao.ProductDaoImpl2;
import com.cg.exception.InvalidProductException;

/**
 * @author gkundu
 *
 */
public class ProductServiceImpl implements ProductService {
	
	private ProductDao dao;
	
	public ProductServiceImpl() {
		
		dao=new ProductDaoImpl2();
	}

	@Override
	public int addProduct(Product p) {
		int id=(int) (Math.random()*100);// new Random().nextInt(100)
		dao.saveProduct(id, p);
		return id;
	}

	@Override
	public boolean removeProduct(int id) throws InvalidProductException {
		
		return dao.deleteProduct(id);
	}

	@Override
	public TreeSet<Product> sortByName() {
		Comparator<Product> pc=(p1,p2)->p1.getName().compareTo(p2.getName());
		TreeSet<Product> tree=new TreeSet<>(pc);
		tree.addAll(dao.getProducts());
		return tree;
	}

	@Override
	public TreeSet<Product> sortByPrice() {
		Comparator<Product> pc=(p1,p2)->(int) (p1.getPrice()-p2.getPrice());
		TreeSet<Product> tree=new TreeSet<Product>(pc);
		tree.addAll(dao.getProducts());
		
		return tree;
	}

	@Override
	public List<Product> getProducts() {
		
		return (List<Product>) dao.getProducts();
	}

}
