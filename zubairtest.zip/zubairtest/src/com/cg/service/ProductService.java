package com.cg.service;

import java.util.List;
import java.util.TreeSet;

import bean.Product;

import com.cg.exception.InvalidProductException;
/**
 * 
 * @author gkundu
 *
 */


public interface ProductService {
	
	int addProduct(Product p);
	List<Product> getProducts();
	boolean removeProduct(int id) throws InvalidProductException;
	
	TreeSet<Product> sortByName();
	TreeSet<Product> sortByPrice();

}
