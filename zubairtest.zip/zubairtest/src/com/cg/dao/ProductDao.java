package com.cg.dao;

import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

import bean.Product;

import com.cg.exception.InvalidProductException;

/**
 * This is the public interface of product Dao
 * @author gkundu
 * @version 1.0
 *
 */
public interface ProductDao {
	/**
	 * Adds a product
	 * @param id
	 * @param p
	 * @return
	 */
	boolean saveProduct(int id,Product p);
	/**
	 * Deletes a Product
	 * @param id
	 * @return
	 * @throws InvalidProductException
	 */
	boolean deleteProduct(int id) throws InvalidProductException;
	/**
	 * returns all product
	 * @return product
	 */
	Collection<Product> getProducts();

}
