/**
 * 
 */
package com.cg.dao;

import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

import bean.Product;

import com.cg.exception.InvalidProductException;

/**
 * @author gkundu
 *
 */
public class ProductDaoImpl implements ProductDao {
	
	private HashMap<Integer,Product> cart;
	
	

	public ProductDaoImpl() {
		
		cart=new HashMap<>();
		
	}

	@Override
	public boolean saveProduct(int id, Product p) {
		cart.put(id,p);
		return true;
	}

	@Override
	public boolean deleteProduct(int id) throws InvalidProductException {
		if(cart.containsKey(id)){
			cart.remove(id);
			return true;
		}
		
	
	throw new InvalidProductException("Product with id not fond"+id);
}

	@Override
	public List<Product> getProducts() {
		
		return (List<Product>) cart.values();
	}

}
