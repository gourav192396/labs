/**
 * 
 */
package com.cg.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

import bean.Product;

import com.cg.exception.InvalidProductException;
import com.cg.util.Util;

/**
 * @author gkundu
 *
 */
public class ProductDaoImpl2 implements ProductDao {
	
	private HashMap<Integer,Product> map;
	
	
	

	public ProductDaoImpl2() {
		
		map=Util.getMap();
		
	}

	@Override
	public boolean saveProduct(int id, Product p) {
		map.put(id,p);
		return true;
	}

	@Override
	public boolean deleteProduct(int id) throws InvalidProductException {
		if(Util.getMap().containsKey(id)){
			map.remove(id);
			return true;
		}
		
	
	throw new InvalidProductException("Product with id not fond"+id);
}

	@Override
	public Collection<Product> getProducts() {
		
		return (List<Product>) map.values();
	}

}
