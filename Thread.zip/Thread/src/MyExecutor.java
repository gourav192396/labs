import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MyExecutor {
public static void main(String[] args) {
	//ExecutorService executor=Executors.newSingleThreadExecutor();//pool of single thread 
	
	ExecutorService executor=Executors.newFixedThreadPool(2);//created pool of 2 threads
	
	Runnable rable=() -> System.out.println("Hello Pool");
	
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {}

	
	executor.execute(rable);
	executor.execute(rable);
	executor.shutdown();// required to shut the executor once used i.e ExecutorService is used
}
}
