import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;


public class MyCallable implements Callable<Integer> {

	@Override
	public Integer call() throws Exception {
	Random generator=new Random();
	int random=generator.nextInt(5);
	if(random==0)                       // to throw execption when zero is in output
		throw new IllegalStateException("Zero");
	
	Thread.sleep(random*1000);
	
	return random;
	
	}
	public static void main(String[] args) {
		FutureTask<Integer>[] tasks=new FutureTask[5];
		for(int i=0;i<tasks.length;i++){
			Callable<Integer> callable=new MyCallable();
			tasks[i]=new FutureTask<>(callable);
			
			Thread t=new Thread(tasks[i]);
			t.start();
		}
		for(int i=0;i<tasks.length;i++){
			try{
				System.out.println(tasks[i].get());
			}
			catch(InterruptedException | ExecutionException e){
				e.printStackTrace();
			}
		}
	}
	

}
