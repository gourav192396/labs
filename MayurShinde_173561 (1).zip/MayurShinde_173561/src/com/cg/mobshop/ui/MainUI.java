package com.cg.mobshop.ui;

import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.util.Util;

public class MainUI {

	public static void main(String[] args) {
		MobileServiceImpl service = new MobileServiceImpl();            // creating service calss object
		Scanner scan = new Scanner(System.in);                       //scanner class object creation
		System.out.println("Welcome to Mobile Shopee"); 
		System.out
				.println("Following are the Mobile Phones Availabl in the shop");
		for (Integer k : Util.getMobileEntries().keySet()) {                 //displaying the available options to the user
			System.out.println("Mobile ID:"
					+ Util.getMobileEntries().get(k).getMobileId() + " Name:"
					+ Util.getMobileEntries().get(k).getName() + " Price "
					+ Util.getMobileEntries().get(k).getPrice()
					+ " Quantity Available "
					+ Util.getMobileEntries().get(k).getQuantity());
		}

		System.out
				.println("Please Select One of the operations you want to perform:");   // taking user input for operations
		System.out.println("1.Sorting\n2.Delete\n3.Exit");
		System.out.println("Enter your choice");
		int choice = scan.nextInt();
		if (choice == 1) {
			System.out
					.println("Please select the Sorting Crieteria from below options");
			System.out
					.println("1.Sort by Mobile Name\n2.Sort by Mobile Price\n3.Sort by Mobile Quantity");
			int ch = scan.nextInt();
			System.out.println(service.SortList(ch));

		} else if (choice == 2) {
			System.out.println("enter the Mobile Code you want to delete");
			int mobcode = scan.nextInt();
			Mobiles mob = service.deleteMobile(mobcode);                     //deleting selected mobcode from the database
			System.out.println("Mobile Phone deleted "+mob);
			
			

		}
		else{
			System.exit(0);
		}
	}
}
