package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.NameComparator;
import com.cg.mobshop.service.PriceComparator;
import com.cg.mobshop.service.QuantityComparator;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO {
	
	List<Mobiles> mobiles;
	PriceComparator pc;
Comparator<? super Collection<Mobiles>> nc;
	@Override
	public List<Mobiles> getMobilesList() {
		for (Integer k : Util.getMobileEntries().keySet()) {
			List<Mobiles> mobiles = Arrays.asList(Util.getMobileEntries().get(k));         //getting the mobiles list in a list
		}
		
		
		return mobiles;
	}

	@Override
	public Mobiles deleteMobile(int mobcode) {
		for (Integer k : Util.getMobileEntries().keySet()) {
			if(k==mobcode){
				Util.getMobileEntries().remove(k);                                  // removing the specified mobile from the list
			}
			return Util.getMobileEntries().get(mobcode);
			
		}
		
		
		return null;
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		pc = new PriceComparator();
		switch(criteria){
		case 2:
		{
			List<Mobiles> mobiles = new ArrayList<Mobiles>();
			Map<Integer,Mobiles> maps = Util.getMobileEntries();
			maps.entrySet().stream().map(x->x.getValue()).sorted(pc).forEach(System.out::println);
			
		
//			for (Integer k : maps.keySet()) {
//				mobiles.add(maps.get(k));
			 mobiles.sort(pc);
			//}
			return mobiles;
		}
		
		case 1:
		{
			List<Mobiles> mobiles = new ArrayList<Mobiles>();
			Map<Integer,Mobiles> maps = Util.getMobileEntries();
//			System.out.println(mobiles.sort(nc));
			for (Integer k : maps.keySet()) {
				mobiles.add(maps.get(k));
			}
			Collections.sort(mobiles);
			System.out.println(mobiles);
			
		}
		
		case 3:
		{
			List<Mobiles> mobiles = new ArrayList<Mobiles>();
			Map<Integer,Mobiles> maps = Util.getMobileEntries();
			for (Integer k : maps.keySet()) {
				mobiles.add(maps.get(k));
			}
			mobiles.sort(new QuantityComparator());
			System.out.println(mobiles);
		}
		}
		
		
		return null;
	}

}
