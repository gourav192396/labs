package com.cg.mobshop.service;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class QuantityComparator implements Comparator<Mobiles> {

	@Override
	public int compare(Mobiles o1, Mobiles o2) {
		return Integer.parseInt(o1.getQuantity())-Integer.parseInt(o2.getQuantity());
	}

}
