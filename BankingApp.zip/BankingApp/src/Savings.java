
public class Savings extends AccountDetail{
	public static int savingCounter=1001;

	public Savings() {
		
	}
	public Savings(int accountNo,String holder,double balance){
		super(savingCounter++,holder,1000);
	}
    public void deposit(double amount){
    	balance+=amount;
    }
    public void withdrawl(double amount)
    {
    	if(amount<=(balance-1000))
    		balance-=amount;
    	else
    		System.out.println("insufficient funds!");
    }
}
