
public class AccountDetail 
}