package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Service("service")
@Transactional
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	private TraineeRepo repo;
	
	@Transactional(readOnly=true)
	@Override
	public List<Trainee> getAll() {
		return repo.getAll();
	}

	@Override
	@Transactional
	public Trainee getOne(int id) throws NoSuchElementException{
			return repo.getOne(id);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public Trainee createTrainee(Trainee trainee) {
		return repo.createTrainee(trainee);
	}

	@Override
	@Transactional
	public Trainee updateTrainee(Trainee trainee) {
		return repo.updateTrainee(trainee);
	}

	@Override
	@Transactional
	public boolean deleteTrainee(int id) {
		return repo.deleteTrainee(id);
	}

}
