package com.cg.repo;

import java.util.List;
import java.util.NoSuchElementException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;

@Repository("repo")
public class TraineeDaoImpl implements TraineeRepo {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	public List<Trainee> getAll() {
		TypedQuery<Trainee> query = em.createQuery("SELECT t FROM Trainee t", Trainee.class);
		return query.getResultList();
	}

	@Override
	public Trainee getOne(int id) {
			return em.find(Trainee.class, id);
	}

	@Override
	public Trainee createTrainee(Trainee trainee) {
		 em.persist(trainee);
		 return trainee;
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		return em.merge(trainee);
	}

	@Override
	public boolean deleteTrainee(int id) {
		Trainee trainee = em.find(Trainee.class,id);
		em.remove(trainee);
		return true;
	}
}
