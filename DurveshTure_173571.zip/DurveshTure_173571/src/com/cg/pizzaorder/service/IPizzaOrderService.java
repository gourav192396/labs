package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService {

	public int placeOrder(Customer customer, PizzaOrder pizza);

	public PizzaOrder getOrderDetails(int orderId) throws PizzaException;

	public int calculatePizzaPrice(String pizzaChoice) throws PizzaException;
	
	public boolean validateMobileNumber(String mobile);
	
	String MobileNumberRegex="(0/91)?[7-9][0-9]{9}";

	int BASE_PIZZA_PRICE = 350;

	int CAPSICUM_TOPPING_PRICE = 30;

	int MUSHROOM_TOPPING_PRICE = 50;

	int JALAPENO_TOPPING_PRICE = 70;

	int PANEER_TOPPING_PRICE = 85;
}
