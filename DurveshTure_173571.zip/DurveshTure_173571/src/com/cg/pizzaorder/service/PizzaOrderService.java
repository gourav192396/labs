package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {

	// creating dao class object
	IPizzaOrderDAO dao = new PizzaOrderDAO();

	// calling placeOrder() method of dao class
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) {

		return dao.placeOrder(customer, pizza);
	}

	// calling getOrderDetails() method of dao class
	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {

		return dao.getOrderDetails(orderId);
	}

	// calculating price of pizza according to topping that user selected
	@Override
	public int calculatePizzaPrice(String pizzaChoice) throws PizzaException {

		pizzaChoice = pizzaChoice.toLowerCase();
		int pizzaPrice = 0;
		switch (pizzaChoice) {

		case "capsicum":
			pizzaPrice = BASE_PIZZA_PRICE + CAPSICUM_TOPPING_PRICE;
			break;

		case "mushroom":
			pizzaPrice = BASE_PIZZA_PRICE + MUSHROOM_TOPPING_PRICE;
			break;

		case "jalapeno":
			pizzaPrice = BASE_PIZZA_PRICE + JALAPENO_TOPPING_PRICE;
			break;

		case "paneer":
			pizzaPrice = BASE_PIZZA_PRICE + PANEER_TOPPING_PRICE;
			break;

		default:
			throw new PizzaException("Invalid topping selection");
		}
		return pizzaPrice;
	}

	// validating mobile number input
	@Override
	public boolean validateMobileNumber(String mobile) {

		if (mobile.matches(MobileNumberRegex)) {
			return true;
		} else {
			return false;
		}
	}

}
