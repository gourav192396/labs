package com.cg.repo;

import java.util.List;
import java.util.NoSuchElementException;

import com.cg.entity.User;

public interface TraineeRepo {

	public List<User> getAll();

	public User getOne(int id);

	public User createTrainee(User user);

	public User updateTrainee(User user);
	
	public boolean deleteTrainee(int id);
}
