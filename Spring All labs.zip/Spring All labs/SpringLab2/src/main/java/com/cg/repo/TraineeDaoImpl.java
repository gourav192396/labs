package com.cg.repo;

import java.util.List;
import java.util.NoSuchElementException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.User;

@Repository("repo")
public class TraineeDaoImpl implements TraineeRepo {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	public List<User> getAll() {
		TypedQuery<User> query = em.createQuery("SELECT t FROM Trainee t", User.class);
		return query.getResultList();
	}

	@Override
	public User getOne(int id) {
			return em.find(User.class, id);
	}

	@Override
	public User createTrainee(User user) {
		 em.persist(user);
		 return user;
	}

	@Override
	public User updateTrainee(User user) {
		return em.merge(user);
	}

	@Override
	public boolean deleteTrainee(int id) {
		User user = em.find(User.class,id);
		em.remove(user);
		return true;
	}
}
