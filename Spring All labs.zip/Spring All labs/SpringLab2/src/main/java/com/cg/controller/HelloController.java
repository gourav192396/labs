package com.cg.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.User;
import com.cg.service.TraineeService;

@Controller
public class HelloController {

	List<String> domains;
	List<User> data;

	@Autowired
	private TraineeService service;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/checkLogin")
	public String checkLogin(@RequestParam("username") String username, @RequestParam("password") String password,Model model) {
		if (username.equals("admin") && password.equals("123456")) {
			return "home";
		} else {
			model.addAttribute("result","Invalid Credentials");
			return "login";
		}
	}

	@RequestMapping(value = "/menu")
	public String navigate(@RequestParam("id") String path, Model model) {

		if(path.equals("getall"))
		{
			data = new ArrayList<User>();
			data = service.getAll();	
			model.addAttribute("data", data);
		}
		
		domains = new ArrayList<String>();
		domains.add("JEE");
		domains.add(".NET");
		domains.add("Main Frame");
		
		model.addAttribute("domains", domains);
		model.addAttribute(path, new User());
		model.addAttribute("trainee", new User());
		return path;
	}

	@RequestMapping(value = "fetchTrainee")
	public ModelAndView fetchOne(@RequestParam("id") int id,@RequestParam("viewName") String viewName,Model model) {
			User user = new User();
			user = service.getOne(id);
			return new ModelAndView(viewName,"trainee",user);
	}

	@RequestMapping(value = "/addTrainee")
	public String addEmployee(@ModelAttribute("add") User user,Model model) {
		User newTrainee = new User();
		newTrainee = service.createTrainee(user);
		model.addAttribute("result","Created Successfully");
		return "add";
	}
	
	@RequestMapping(value = "deleteTrainee")
	public String deleteEmployee(@RequestParam("id") int id,Model model)
	{
		boolean result = service.deleteTrainee(id);
		if(result)
			model.addAttribute("result","Deleted Successfully");
		else
			model.addAttribute("result","Could Not Delete");
		return "delete";
	}
	
	@RequestMapping(value = "modifyTrainee")
	public String updateEmployee(@ModelAttribute("trainee") User user,Model model)
	{
		User trained = new User();
		trained = service.updateTrainee(user);
		model.addAttribute("result","Updated Successfully");
		return "modify";
	}
	

}
