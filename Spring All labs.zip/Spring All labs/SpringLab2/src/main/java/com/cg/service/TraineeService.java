package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import com.cg.entity.User;

public interface TraineeService {

	public List<User> getAll();
	
	public User getOne(int id);
	
	public User createTrainee(User user);
	
	public User updateTrainee(User user);
	
	public boolean deleteTrainee(int id);
}
