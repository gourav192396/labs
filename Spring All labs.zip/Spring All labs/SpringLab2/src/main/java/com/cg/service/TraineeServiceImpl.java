package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.User;
import com.cg.repo.TraineeRepo;

@Service("service")
@Transactional
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	private TraineeRepo repo;
	
	@Transactional(readOnly=true)
	@Override
	public List<User> getAll() {
		return repo.getAll();
	}

	@Override
	@Transactional
	public User getOne(int id) throws NoSuchElementException{
			return repo.getOne(id);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public User createTrainee(User user) {
		return repo.createTrainee(user);
	}

	@Override
	@Transactional
	public User updateTrainee(User user) {
		return repo.updateTrainee(user);
	}

	@Override
	@Transactional
	public boolean deleteTrainee(int id) {
		return repo.deleteTrainee(id);
	}

}
