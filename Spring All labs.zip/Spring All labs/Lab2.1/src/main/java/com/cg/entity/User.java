package com.cg.entity;

public class User {

	private String traineeName;
	private int id;
	private char gender;

	private String Domain;
	// private String email;
	// private String[] skillSet;
	private String city;

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getDomain() {
		return Domain;
	}

	public void setDomain(String domain) {
		Domain = domain;
	}

	/*public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
*/
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "User [traineeName=" + traineeName + ", id=" + id + ", gender=" + gender + ", Domain=" + Domain
				+ ", city=" + city + "]";
	}
	
	

}
