package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.User;
@Repository("repo")
public class TraineeRepoImpl implements TraineeRepo {
	
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	public List<User> getAll() {
		TypedQuery<User> qu = em.createQuery("SELECT t FROM Trainee t", User.class);
		return qu.getResultList();
		
	}

	public User getOne(int id) {
		
		return em.find(User.class,id);
	}

	public User createTrainee(User trainee) {
		em.persist(trainee);
		return trainee;
	}

	public User updateTrainee(User trainee) {
		
		return em.merge(trainee);
	}

	public String deleteTrainee(int id) {
	
		 User user=em.find(User.class,id);
		  em.remove(user);
		  return  "Traineee deleted successfully";
	}
	
	

}
