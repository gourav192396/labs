package com.cg.control;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Login;
import com.cg.entity.User;
import com.cg.service.TraineeService;

@Scope("session")
@Controller
@RequestMapping(value="trainee")
public class UserController {
	
	ArrayList<User> dataList;
	ArrayList<String> domainList;
	
	@Autowired TraineeService service;
	
	/*@RequestMapping(path = "/", method = RequestMethod.GET)
	public String login() {
		return "login";
	}*/
	
	@RequestMapping(value="showLogin")
	public String prepareLogin(Model model)
	{
		System.out.println("In prepareLogin() method");
		model.addAttribute("login",new Login());
		return "login";
	}
	
	@RequestMapping(value="checkLogin")
	public String checkLogin(Model model,Login login)
	{
		 if(login.getUserName().equals("Gourav")&& (login.getPassword().equals("123456")) ) {
	  	return "loginSuccess";
		 }else {
			 model.addAttribute("response","invalid username");
			 return "login";
		 }
	}
	@RequestMapping(value="/showRegister")
	
	public String navigate(@RequestParam("id") String path, Model model) {

		if(path.equals("getall"))
		{
			dataList = new ArrayList<User>();
			dataList = (ArrayList<User>) service.getAll();	
			model.addAttribute("data", dataList);
		}
		
		domainList = new ArrayList<String>();
		domainList.add("Java");
		domainList.add("SAP");
		domainList.add("Oraps");
		
		model.addAttribute("domains", domainList);
		model.addAttribute(path, new User());
		model.addAttribute("trainee", new User());
		return path;
	}
	

	
	/*public String prepareRegister(Model model)
	{
		dataList =new ArrayList<String>();
		
		dataList.add("Mumbai");
		dataList.add("Bangalore");
		dataList.add("Chennai");
		dataList.add("Delhi");
		
		domainList =new ArrayList<String>();
		
		domainList.add("Java");
		domainList.add("SAP");
		domainList.add("Database");
		domainList.add("Oraps");
		
		model.addAttribute("cityList",dataList);
		model.addAttribute("domainList",domainList);
		
		model.addAttribute("user",new User());
	    return "register";	
	}*/

	
	@RequestMapping(value = "fetchTrainee")
	public ModelAndView fetchOne(@RequestParam("id") int id,@RequestParam("viewName") String viewName,Model model) {
			User user = new User();
			user = service.getOne(id);
			return new ModelAndView(viewName,"trainee",user);
	}

	@RequestMapping(value = "/addTrainee")
	public String addEmployee(@ModelAttribute("add") User user,Model model) {
		User newTrainee = new User();
		newTrainee = service.createTrainee(user);
		model.addAttribute("result","Created Successfully");
		return "add";
	}
	
	@RequestMapping(value = "deleteTrainee")
	public String deleteEmployee(@RequestParam("id") int id,Model model)
	{
		String result = service.deleteTrainee(id);
		if(result != null)
			model.addAttribute("result","Deleted Successfully");
		else
			model.addAttribute("result","Could Not Delete");
		return "delete";
	}
	
	@RequestMapping(value = "modifyTrainee")
	public String updateEmployee(@ModelAttribute("trainee") User user,Model model)
	{
		User train = new User();
		train = service.updateTrainee(user);
		model.addAttribute("result","Updated Successfully");
		return "modify";
	}
	 
	

}
