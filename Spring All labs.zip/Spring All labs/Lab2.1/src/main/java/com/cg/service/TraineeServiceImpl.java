package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.User;
import com.cg.repo.TraineeRepo;
@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
@Autowired TraineeRepo repo;
	public List<User> getAll() {
		repo.getAll();
		return (List<User>) repo;
	}

	public User getOne(int id) {
		repo.getOne(id);
		return (User) repo;
	}

	public User createTrainee(User trainee) {
		
		return repo.createTrainee(trainee);
	}

	public User updateTrainee(User trainee) {
		
		return repo.updateTrainee(trainee);
	}

	public String deleteTrainee(int id) {
		
		return repo.deleteTrainee(id);
	}

}
