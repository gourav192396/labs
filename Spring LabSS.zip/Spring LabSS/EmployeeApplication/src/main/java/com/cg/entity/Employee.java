package com.cg.entity;

public class Employee {

	public Employee() {
	}
	private int employeeId;
	private String name;
	private double salary;
	private String businessUnit;
	private int age;
	private SBU sbu;
	
	public Employee(int employeeId, String employeeName, double salary, String businessUnit, int age) {
		this.employeeId = employeeId;
		this.name = employeeName;
		this.salary = salary;
		this.businessUnit = businessUnit;
		this.age = age;
	}
	
	

	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public String getBusinessUnit() {
		return businessUnit;
	}



	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public SBU getSbu() {
		return sbu;
	}



	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}



	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + name + ", salary=" + salary
				+ ", businessUnit=" + businessUnit + ", age=" + age + ",\n sbu=" + sbu + "]";
	}
	public String display() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + name + ", salary=" + salary
				+ ", businessUnit=" + businessUnit + ", age=" + age + "]";
	}
	public String displayList() {
		return "Employee Details\n----------\nEmployee ID  : " + employeeId + "\nEmployeeName : " + name
				+ "\nEmployee Salary : " + salary
				+ "\nEmployee Business Unit : " + businessUnit + "\nEmployee Age : " + age;
	}
}
