package com.cg.client;

import static org.junit.Assert.assertNotNull;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.entity.Employee;
import com.cg.entity.SBU;

public class Client {
	public static void main(String[] args) {
		ApplicationContext ctx1 = new ClassPathXmlApplicationContext("Employee1.xml");
		ApplicationContext ctx2 = new ClassPathXmlApplicationContext("Employee2.xml");
		ApplicationContext ctx3 = new ClassPathXmlApplicationContext("Employee3.xml");
		// injecting values into bean using DI
		Employee emp = (Employee) ctx1.getBean("emp");
		assertNotNull("Null object", emp);
		System.out.println(emp.display());

		// injecting employee bean to SBU bean
		Employee empRef = (Employee) ctx2.getBean("emp");
		assertNotNull("Null object", empRef);
		System.out.println(empRef);

		// Display the SBU details, followed by a list of all employees in that BU.
		SBU sbu = (SBU) ctx3.getBean("sbu");
		System.out.println(sbu + "\n");
		assertNotNull("Null object", sbu);
		for (Employee empRecord : sbu.getEmpList()) {
			System.out.println(empRecord.displayList());
		}
	}
}
