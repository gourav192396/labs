package com.cg.repo;

import java.util.List;

import com.cg.entity.User;



public interface TraineeRepo {

	public List<User> getAll();

	public User getOne(int id);

	public User createTrainee(User trainee);

	public User updateTrainee(User trainee);
	
	public String deleteTrainee(int id);
}
