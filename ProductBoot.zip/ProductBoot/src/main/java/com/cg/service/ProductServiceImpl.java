package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;
@Service
public class ProductServiceImpl implements ProductService {
@Autowired
ProductRepo repo;
	@Override
	public Product get(int id) {
		
		Product p=repo.findById(id).get();
		return p;
	}

	@Override
	public void addProduct(Product p) {
	repo.save(p);
	}

	@Override
	public void removeProduct(int id) {
		Product p=repo.findById(id).get();
		repo.delete(p);
		
	}

	@Override
	public void updateProduct(int id) {
		Product p=repo.findById(id).get();
		repo.save(p);
		
	}

	

	

}
