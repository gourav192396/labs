package com.cg.service;

import com.cg.entity.Product;

public interface ProductService {
	
	//public void saveProduct(Product p);
	public Product get(int id);
	public void addProduct(Product p);
	public void  removeProduct(int id);
	public void updateProduct(int id);


}
