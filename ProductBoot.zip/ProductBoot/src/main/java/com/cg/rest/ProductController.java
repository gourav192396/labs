package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductServiceImpl;

@RestController
public class ProductController {
	@Autowired
	ProductServiceImpl service;
	
	@PostMapping("/add")
	public String addProduct(@RequestParam("name") String name,@RequestParam("price") double price ) {
	Product p=new Product();
	p.setName(name);
	p.setPrice(price);
	service.addProduct(p);
	return "Product Addded";
		
	}
	@GetMapping(name="/product")
	public Product get(@RequestParam("id") int id) {
		Product p=service.get(id);
		return p;
	}
	@DeleteMapping("/delete")
	public String removeProduct(@RequestParam("id") int id) {
		service.removeProduct(id);
		return "Product Removed";
		
	}

}
