package com.cg.client;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Employee;
import com.cg.entity.SBU;


public class Client {
	public static void main(String[] args) {
		ApplicationContext ctx1 = new ClassPathXmlApplicationContext("Employee1.xml");
		ApplicationContext ctx2 = new ClassPathXmlApplicationContext("Employee2.xml");
		ApplicationContext ctx3 = new ClassPathXmlApplicationContext("Employee3.xml");
	
		/*Inject values into bean using DI and display all values*/
		Employee emp = (Employee) ctx1.getBean("emp");
		assertNotNull("Null object", emp);
		System.out.println(emp.display());

		/*Inject the SBU bean to the Employee bean and provide a method to retrieve SBU details*/ 
		Employee empRef = (Employee) ctx2.getBean("emp");
		assertNotNull("Null object", empRef);
		System.out.println(empRef);

		/*	Display the SBU details, followed by a list of all employees in that BU.
		To inject employee objects into the SBU bean, using �List� collection. */
		SBU sbu = (SBU) ctx3.getBean("sbu");
		System.out.println(sbu + "\n");
		assertNotNull("Null object", sbu);
		for (Employee empRecord : sbu.getEmpList()) {
			System.out.println(empRecord.displayList());
		}
	}
}
