package com.cg.test;

import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Employee;
import com.cg.entity.SBU;

public class TestEmployee {	
	Scanner sc = new Scanner(System.in);
	int empId;
	Map<Integer,Employee> mapEmployee;
	ApplicationContext ctx1 = new ClassPathXmlApplicationContext("Employee1.xml");
	ApplicationContext ctx2 = new ClassPathXmlApplicationContext("Employee2.xml");
	ApplicationContext ctx3 = new ClassPathXmlApplicationContext("Employee3.xml");
	ApplicationContext ctx4 = new ClassPathXmlApplicationContext("Employee4.xml");
	@Test
	public void testEmployee() {
	
		Employee emp = (Employee) ctx1.getBean("emp");
		assertNotNull("Null object", emp);
		System.out.println(emp.display());
	}
	
	@Test
	public void testEmployeeRef() {
		Employee emp = (Employee) ctx2.getBean("emp");
		assertNotNull("Null object", emp);
		System.out.println(emp);
	}
	
	@Test
	public void testEmployeeList() {
		SBU sbu = (SBU) ctx3.getBean("sbu");
		System.out.println(sbu + "\n");
		assertNotNull("Null object", sbu);
		for (Employee emp : sbu.getEmpList()) {
			System.out.println(emp.displayList());
		}
	}
	
	@Test
	public void findEmployeeDetails() {
		SBU sbu = (SBU) ctx4.getBean("sbu");
		System.out.println("Emploee Id: ");
		empId = sc.nextInt();
		mapEmployee = sbu.getEmpMap();
		Employee e = mapEmployee.get(empId);
		System.out.println(e.display());
	}
	@Test
	public void findEmployeeDetailsByList() {
		SBU sbu = (SBU) ctx3.getBean("sbu");
		System.out.println("Emploee Id: ");
		empId = sc.nextInt();
		assertNotNull("Null object", sbu);
		for (Employee emp : sbu.getEmpList()) {
			if (emp.getEmployeeId() == empId) {
				System.out.println(emp.displayList());
			}
		}
	}
}
