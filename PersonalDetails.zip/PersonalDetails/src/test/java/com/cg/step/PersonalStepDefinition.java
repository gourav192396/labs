package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() {

		System.setProperty("webdriver.chrome.driver",
				"mydriver/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Personal Detail Page$")
	public void user_is_on_Personal_Detail_Page() throws Throwable {
		String url = "file:///C:/Users/gkundu/workspace/PersonalDetails/html/PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver,personal);
	}

	@When("^User enter invalid First Name$")
	public void user_enter_invalid_First_Name() throws Throwable {
		//personal.selectUser(0);
		personal.setFirstName("");
		Thread.sleep(1000);
	}

	@Then("^Validate first name$")
	public void validate_first_name() throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		
	}

	@When("^User enters Invalid Last Name$")
	public void user_enters_Invalid_Last_Name() throws Throwable {
		personal.setFirstName("Gourav");
		personal.setLastName("");
		Thread.sleep(2000);
	}

	@Then("^Validate last name$")
	public void validate_last_name() throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Invalid email id$")
	public void user_enters_Invalid_email_id() throws Throwable {
	personal.setFirstName("Gourav");
	personal.setLastName("Kundu");
		personal.setEmail("");
		Thread.sleep(1000);
	}

	@Then("^Validate Email$")
	public void validate_Email() throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Invalid phone number$")
	public void user_enters_Invalid_phone_number() throws Throwable {
		personal.setFirstName("Gourav");
		personal.setLastName("Kundu");
		personal.setEmail("gour.k.21@cg");
		personal.setPhoneNumber("");
	}

	@Then("^Validate phone$")
	public void validate_phone() throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Invalid address line (\\d+)$")
	public void user_enters_Invalid_address_line(int arg1) throws Throwable {
		personal.setFirstName("Gourav");
		personal.setLastName("Kundu");
		personal.setEmail("gour.k.21@cg");
		personal.setPhoneNumber("123456789");
		personal.setAddress("");
	}

	@Then("^Validate address (\\d+)$")
	public void validate_address(int arg1) throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Invalid city name$")
	public void user_enters_Invalid_city_name() throws Throwable {
		personal.setFirstName("Gourav");
		personal.setLastName("Kundu");
		personal.setEmail("gour.k.21@cg");
		personal.setPhoneNumber("123456789");
		personal.setAddress("Asadhsbdh");
		personal.setCity(0);
	}

	@Then("^Validate city$")
	public void validate_city() throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters Invalid state$")
	public void user_enters_Invalid_state() throws Throwable {
		personal.setFirstName("Gourav");
		personal.setLastName("Kundu");
		personal.setEmail("gour.k.21@cg");
		personal.setPhoneNumber("123456789");
		personal.setAddress("Asadhsbdh");
		personal.setCity(1);
		personal.setState(1);
	}

	@Then("^Validate state$")
	public void validate_state() throws Throwable {
		personal.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	@When("^User enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
		personal.setFirstName("Gourav");
		personal.setLastName("Kundu");
		personal.setEmail("gour.k.21@cg");
		personal.setPhoneNumber("123456789");
		personal.setAddress("Asadhsbdh");
		personal.setCity(1);
		personal.setState(1);
	}

	@Then("^successful accepted$")
	public void successful_accepted() throws Throwable {
	   personal.clickNext();
	}

}
