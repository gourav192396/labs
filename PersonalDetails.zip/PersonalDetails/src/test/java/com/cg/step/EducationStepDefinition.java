package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	private WebDriver driver;
	private Education edu;
	
	@Before
	public void init() {

		System.setProperty("webdriver.chrome.driver",
				"mydriver/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@After
	public void destroy() {
		driver.quit();
	}
	@Given("^User is on Graduation Page$")
	public void user_is_on_Graduation_Page() throws Throwable {
		String url="file:///C:/Users/gkundu/workspace/PersonalDetails/html/EducationalDetails.html"; 
		driver.get(url);
		edu=new Education();
		PageFactory.initElements(driver,edu);
		/*if(driver.getTitle().equals("Education Details")){
			   System.out.println("Details are correct");
		   }else{
			   System.exit(0);
			   driver.quit();
		   }*/
	}

	@When("^User enters invalid Graduation details$")
	public void user_enters_invalid_Graduation_details() throws Throwable {
	   edu.setGraduation("");
	   Thread.sleep(1000);
	    
	}

	@Then("^Validate graduation$")
	public void validate_graduation() throws Throwable {
		edu.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters invalid Percentage details$")
	public void user_enters_invalid_Percentage_details() throws Throwable {
		
		edu.setGraduation("Engg");
		edu.setPercentage("");
		Thread.sleep(1000);
	}

	@Then("^Validate percentage$")
	public void validate_percentage() throws Throwable {
		edu.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters invalid Passing Year details$")
	public void user_enters_invalid_Passing_Year_details() throws Throwable {
		
		edu.setGraduation("Engg");
		edu.setPercentage("80");
		edu.setPassingYear("");
		Thread.sleep(1000);
		
	}

	@Then("^Validate passing year$")
	public void validate_passing_year() throws Throwable {
		edu.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters invalid Project Name details$")
	public void user_enters_invalid_Project_Name_details() throws Throwable {
		
		edu.setGraduation("Engg");
		edu.setPercentage("80");
		edu.setPassingYear("2019");
		edu.setProjectName("");
		Thread.sleep(1000);
		
	}

	@Then("^Validate project name$")
	public void validate_project_name() throws Throwable {
		edu.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters invalid Technologies details$")
	public void user_enters_invalid_Technologies_details() throws Throwable {
		
		edu.setGraduation("Engg");
		edu.setPercentage("80");
		edu.setPassingYear("2019");
		edu.setProjectName("Shopping Cart");
		edu.setTechnologies("");
		Thread.sleep(1000);
		
	}

	@Then("^Validate technologies$")
	public void validate_technologies() throws Throwable {
		edu.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters invalid Other Technologies details$")
	public void user_enters_invalid_Other_Technologies_details() throws Throwable {
		edu.setGraduation("Engg");
		edu.setPercentage("80");
		edu.setPassingYear("2019");
		edu.setProjectName("Shopping Cart");
		edu.setTechnologies("Spring and angular");
		edu.setOtherTechnologies("");
	
	}

	@Then("^Validate other technologies$")
	public void validate_other_technologies() throws Throwable {
		edu.clickNext();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
}
