package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Education {
	@FindBy(id = "txtGraduation")
	WebElement graduation;
	@FindBy(id = "txtPercent")
	WebElement percentage;
	@FindBy(id = "txtPassingYear")
	WebElement passingYear;
	@FindBy(id = "txtProjectName")
	WebElement projectName;
	@FindBy(id = "txtTechnologies")
	WebElement technologies;
	@FindBy(id = "txtOther")
	WebElement otherTechnologies;
	@FindBy(id = "regMe")
	private WebElement next;

	public String getGraduation() {
		return this.graduation.getAttribute("value");
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public String getPercentage() {
		return this.percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return this.passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return this.projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getTechnologies() {
		return this.technologies.getAttribute("value");
	}

	public void setTechnologies(String technologies) {
		this.technologies.sendKeys(technologies);
	}

	public String getOtherTechnologies() {
		return this.otherTechnologies.getAttribute("value");
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}

	public String getNext() {
		return next.getAttribute("value");
	}

	public void setNext(String next) {
		this.next.sendKeys(next);
	}

	public void clickNext() {
		next.click();
	}

}
