package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	
	
	@FindBy(id = "txtFirstName")
	private WebElement firstName;
	
	@FindBy(id = "txtLastName")
	private WebElement lastName;
	
	@FindBy(id = "txtEmail")
	private WebElement email;
	
	@FindBy(id = "txtPhone")
	private WebElement phoneNumber;
	
	@FindBy(id = "txtAddress1")
	private WebElement address;

	
	@FindBy(id = "txtAddress2")
	private WebElement area;

	@FindBy(name = "city")
	private WebElement city;

	@FindBy(name = "state")
	private WebElement state;
	
	@FindBy(id="a")
    private WebElement next;

	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);;
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);;
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public String getPhoneNumber() {
		return this.phoneNumber.getAttribute("value");
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.sendKeys(phoneNumber); ;
	}

	public String getAddress() {
		return this.address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);;
	}

	public String getArea() {
		return this.area.getAttribute("value");
	}

	public void setArea(String area) {
		this.area.sendKeys(area);;
	}

	public String getCity() {
		return this.city.getAttribute("value");
	}

	public void setCity(int i) {
		Select select=new Select(city);
		select.selectByIndex(i);
	}

	public String getState() {
		return this.state.getAttribute("value");
	}

	public void setState(int i) {
		Select select=new Select(state);
		select.selectByIndex(i);
	}
	
	public String getNext() {
		return next.getAttribute("value");
	}

	public void setNext(String next) {
		this.next.sendKeys(next);
	}
	
	
	
	

	public void clickNext(){
		next.click();
	}

	

}
