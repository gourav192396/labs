import { NgModule } from '@angular/core';
import {  MatButtonModule, MatFormFieldModule, MatInputModule} from '@angular/material';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  imports: [
    MatButtonModule,MatFormFieldModule,MatInputModule,MatButtonModule
  ],
  exports:[
    MatButtonModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule
  ]
})
export class MaterialModule { }
