import { Component, OnInit, Input } from '@angular/core';
import { UserModel } from 'src/models/User';
import { Router } from '@angular/router';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  @Input() user: UserModel

  constructor(private route:Router) {
    this.user = new UserModel();
   }

  ngOnInit() {
  }
  navigateToDisplayCustomer(){
    this.route.navigate(['/show_customer']);

  }

}
