package Exception;

public class IllegalFormatException extends Exception{

	public IllegalFormatException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IllegalFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

