package ui;

import java.time.Year;
import java.util.Scanner;

import service.ServiceInsu;
import bean.Vehicle;

public class UserInterface {
	public static void main(String[] args) {
		int choice;
		double premium=0;
	    String builtYear;
		Scanner sc=new Scanner(System.in);
		ServiceInsu service=new ServiceInsu();
		Vehicle b1=new Vehicle("KTM",250,150000,"2014");
		Vehicle b2=new  Vehicle("Pulsar",220,120000,"2014");
		Vehicle b3=new Vehicle("CBR",150,110000,"2014");
		Vehicle b4=new Vehicle("Unicorn",150,90000,"2014");
		Vehicle b5=new Vehicle("Splendor",110,60000,"2014");
		

		
			System.out.println("Please select the vehicle you would like to insure \n 1.KTM 250 \n 2.Pulsar \n 3.CBR 150 \n 4.Unicorn 150 \n 5.Splendor 110");
		    
		    System.out.println("please enter a valid choice:");
		    choice = sc.nextInt();
		switch(choice){
		
		
		case 1:{
			System.out.println("Enter bike registration year");
		
		builtYear=sc.next();
		b1.setBuiltYear(builtYear);
	    service.addBike(b1);
	    System.out.println("Following are the type insurnce available \n 1.3rd Party \n 2.Comprehensive");
	   int choice2=sc.nextInt();
	    	if(choice2==1){
				premium = service.calculatePremium3rdParty(b1);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice2==2){
				premium = service.calculatePremiumComprehensive(b1);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
	    	break;
		}

		case 2:{
			System.out.println("Enter bike registration year");
		
		builtYear=sc.next();
		b1.setBuiltYear(builtYear);
	    service.addBike(b2);
	    System.out.println("Following are the type insurnce available \n 1.3rd Party \n 2.Comprehensive");
	    int choice2=sc.nextInt();
	    	if(choice2==1){
				premium = service.calculatePremium3rdParty(b2);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice2==2){
				premium = service.calculatePremiumComprehensive(b2);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
	    	break;
		}

		case 3:{
			System.out.println("Enter bike registration year");
		
		builtYear=sc.next();
		b1.setBuiltYear(builtYear);
	    service.addBike(b3);
	    System.out.println("Following are the type insurnce available \n 1.3rd Party \n 2.Comprehensive");
	    int choice2=sc.nextInt();
	    	if(choice==1){
				premium = service.calculatePremium3rdParty(b3);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice==2){
				premium = service.calculatePremiumComprehensive(b3);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
	    	break;
		}

		case 4:{
			System.out.println("Enter bike registration year");
		
		builtYear=sc.next();
		b1.setBuiltYear(builtYear);
	    service.addBike(b4);
	    System.out.println("Following are the type insurnce available \n 1.3rd Party \n 2.Comprehensive");
	    int choice2=sc.nextInt();
	    	if(choice==1){
				premium = service.calculatePremium3rdParty(b4);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice==2){
				premium = service.calculatePremiumComprehensive(b4);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
	    	break;
		}

		case 5:{
			System.out.println("Enter bike registration year");
		
		builtYear=sc.next();
		b1.setBuiltYear(builtYear);
	    service.addBike(b5);
	    System.out.println("Following are the type insurnce available \n 1.3rd Party \n 2.Comprehensive");
	    int choice2=sc.nextInt();
	    	if(choice==1){
				premium = service.calculatePremium3rdParty(b5);
				System.out.println("Your premium for the bike Third Party Insurance is:"+premium);
			}
			else if(choice==2){
				premium = service.calculatePremiumComprehensive(b5);
				System.out.println("Your premium for the bike Comprehensive Insurance is:"+premium);
			}
	    	break;
		}
		default:
			System.out.println("Invalid Choice");

		}
		}
		
		
		}
		

		
	

