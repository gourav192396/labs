package dao;

import java.util.ArrayList;
import java.util.List;

import bean.Vehicle;

public class Dao {
	List<Vehicle> twoWheeler = new ArrayList<Vehicle>();
	public void insurance(Vehicle b){
		
		twoWheeler.add(b);
		
		
	}

}
