package bean;

public class Vehicle {
	
	private String bikeName;
	private long price;
	private String builtYear;
	private int engineCc;

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public String getBuiltYear() {
		return builtYear;
	}

	public void setBuiltYear(String builtYear) {
		this.builtYear = builtYear;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}
	

	public int getEngineCc() {
		return engineCc;
	}

	public void setEngineCc(int engineCc) {
		this.engineCc = engineCc;
	}
	
	


	public Vehicle( String bikeName, int engineCc,long price, String builtYear) {
		super();
		
		this.bikeName = bikeName;
		this.price = price;
		this.builtYear = builtYear;
		this.engineCc = engineCc;
	}

	@Override
	public String toString() {
		return "Vehicle [bikeName=" + bikeName + ", price=" + price
				+ ", builtYear=" + builtYear + ", engineCc=" + engineCc + "]";
	}

	

	

	
}
