package service;

import bean.Vehicle;
import dao.Dao;

public class ServiceInsu {
	Dao db = new Dao();
	String currentyear = "2019";
	

	public void addBike(Vehicle b) {

		db.insurance(b);

	}
	public double calculatePremium3rdParty(Vehicle b){
		double deppercent=5;
		double deppercent2=10;
		double temp=b.getPrice();

		int noOfYears = Integer.parseInt(currentyear)-Integer.parseInt(b.getBuiltYear());
		if(noOfYears>3){
			double temp2,temp1 = 0;
		for(int i=0;i<3;i++){
			 temp1=((100-deppercent)*temp)/100;
			 
		}
		
		temp2=temp1;
		for(int i=0;i<=noOfYears-3;i++){
			temp2=((100-deppercent2)*temp2)/100;
		}
		return temp2*0.03;
		}
		
		else{
			double temp2 = 0,temp1;
			for(int i=0;i<=noOfYears;i++){
				 temp2=((100-deppercent)*temp)/100;
				 
			}
			return temp2*0.03;
		}
		
		
	}
	public double calculatePremiumComprehensive(Vehicle b){
		double deppercent = 5;
		double deppercent2 = 10;
		double temp = b.getPrice();
		
		int noOfYears = Integer.parseInt(currentyear)-Integer.parseInt(b.getBuiltYear());
		if(noOfYears>3){
			double temp2 = 0,temp1 = 0;
		for(int i=0;i<3;i++){
			 temp1=((100-deppercent)*temp)/100;
			 
		}
		
		temp2=temp1;
		for(int i=0;i<=noOfYears-3;i++){
			temp2=((100-deppercent2)*temp2)/100;
		}
		return temp2*0.05;
		}
		
		else{
			double temp2 = 0,temp1 = 0;
			for(int i=0;i<=noOfYears;i++){
				 temp2=((100-deppercent)*temp2)/100;
				 
			}
			return temp2*0.05;
		}
		
//		double premium = temp2*0.05;
		
		
		
		//double depriciatedValue = b.getPrice().
		
	}
}
