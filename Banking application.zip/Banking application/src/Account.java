public abstract class Account implements Bank {
	private int accountNo;
	private String holderName;
	protected double balance;
	
	protected Transaction[] txns;
	protected int idx;

	public Account(int actNo, String holder, int i) {
		this.accountNo = actNo;
		this.holderName = holder;
		this.balance = i;
	}
	@Override
	public void statement(){
		System.out.println("Statement of a/c:"+accountNo);
		for(int i=0;i<idx;i++){
			System.out.println(txns[i].print());
		}
	}

	public Account() {

	}

	public void summary() {
		System.out.println("Name: " + holderName);
		System.out.println("Account no" + accountNo);
		System.out.println("Current balance: " + balance);
	}

}
***************************************************************************************************
SAVING ACCOUNT

public Savings(String holder) {
		super(savingCounter++, holder, MIN_SAVING_ACNT);
		txns = new Transaction[10];
		txns[idx++] = new Transaction("CR", MIN_SAVING_ACNT, MIN_SAVING_ACNT);

	}

	public void deposit(double amount) {

		balance = balance + amount;
		txns[idx++] = new Transaction("CR", amount, balance);
	}

	public void withdraw(double amount) throws BalanceException {
		if (amount <= (balance - MIN_SAVING_ACNT)) {
			balance = balance - amount;
			txns[idx++] = new Transaction("DR", amount, balance);

		}
		else{
			throw new BalanceException("insufficient funds");
		}

	}

}
