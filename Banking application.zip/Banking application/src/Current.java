public class CurrentAccount extends Account {
	int overdraft;
	private static int currentCounter = 2001;

	public CurrentAccount(String holder) {

		super(currentCounter++, holder, INIT_CURRENT_ACNT);
		this.overdraft = 10000;
		txns = new CurrentKey[10];
		txns[idx++] = new CurrentKey("CR", INIT_CURRENT_ACNT, balance,
				OVERDRAFT_LIMIT);
	}

	@Override
	public void deposit(double amount) {
		overdraft += amount;
		if (overdraft > OVERDRAFT_LIMIT) {
			balance += (overdraft - OVERDRAFT_LIMIT);
			overdraft = OVERDRAFT_LIMIT;

		}
		txns[idx++] = new CurrentKey("CR", amount, balance, overdraft);
	}

	@Override
	public void withdraw(double amount) throws BalanceException {

		if (amount <= (balance + overdraft)) {
			balance -= amount;
			if (balance < MIN_CURRENT_ACNT) {
				overdraft += balance;
				balance = MIN_CURRENT_ACNT;

			}
			txns[idx++] = new CurrentKey("DR", amount, balance, overdraft);
		} else {
			throw new BalanceException("insufficient funds");
		}
	}

}

