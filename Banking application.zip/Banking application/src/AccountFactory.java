
public final class AccountFactory {
	private AccountFactory(){
		
	}
public Bank OpenAccount(String type,String holder){
	Bank acnt=null;
	if(type.equlsIgnoreCase("Current"))
		acnt=new Current(holder);
	else
		acnt=new Savings(holder);
	return acnt;
}
}
