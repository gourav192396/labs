public class BalanceException extends Exception {

	public BalanceException() {
		super();
	}

	public BalanceException(String m) {
		super(m);
	}

}