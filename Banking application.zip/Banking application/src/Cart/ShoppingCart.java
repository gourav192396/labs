package Cart;

public class ShopingCart{
	int i;
	Product[] cart=new Product[5];
	
	
	void addProduct(Product p){
		cart[i++]=p;
	}
	
	}
