package Cart;

public class Product {
 String product;

public Product(String product) {
	super();
	this.product = product;
}



}






