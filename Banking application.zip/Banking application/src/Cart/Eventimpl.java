package Cart;

public class Eventimpl implements Event {

	@Override
	public void doSomething() {
		System.out.println("First Event");
	}
	class InnerEventImpl implements Event{

		@Override
		public void doSomething() {
			System.out.println("second event");
			
		}
		
	}
	public void secondImpl(){
		Event e=new InnerEventImpl();
		e.doSomething();
	}
	public void thirdImpl(){
		class NestedEventImpl implements Event{

			@Override
			public void doSomething() {
				System.out.println("third event");
				
			}
			
		}
		Event e=new NestedEventImpl();
		e.doSomething();
	};
	public void oneMoreImpl(){
		Event e=new Event(){
		@Override
		public void doSomething(){
			System.out.println("fourth event");
		}
	};
	e.doSomething();
	}
	public void oneLastImpl(){
		Event e=()-> System.out.println("fifth event");
		e.doSomething();
	}
public static void main(String[] args){
	Eventimpl e=new Eventimpl();
	e.doSomething();
	e.secondImpl();
	e.thirdImpl();
	e.oneMoreImpl();
	e.oneLastImpl();
}
}
