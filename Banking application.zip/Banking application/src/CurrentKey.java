public class CurrentKey extends Transaction {
	private int overdraft;

	public CurrentKey() {
	}

	@Override
	public String print() {
		return super.print() + "\t" + overdraft;
	}

	public CurrentKey(String type, double amount, double balance, int overdraft) {
		super(type, amount, balance);
		this.overdraft = overdraft;
	}
	

}
