public interface Bank {
	void deposit(double amount);

	void withdraw(double amount) throws BalanceException;

	void summary();
	//constants
	 int INIT_SAVING_ACNT = 1000;
	 int INIT_CURRENT_ACNT = 5000;
	public static final int MIN_SAVING_ACNT = 1000;
	public static final int MIN_CURRENT_ACNT = 0;
	public static final int OVERDRAFT_LIMIT = 10000;
	
	void statement();

}

