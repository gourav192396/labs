package shoppingcart;

public class Watch extends Product {

}
