package shoppingcart;

public class Shoe extends Product {

}
