package shoppingcart;

public abstract class Product {

}
