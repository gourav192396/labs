package com.capgemini.xyz.dao;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Transaction;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.InsufficientBalanceException;
import com.capgemini.xyz.service.CustomerComparator;

public class SetCustomerDao implements ICustomerDAO{

	CustomerComparator ccom= new CustomerComparator();
	Set<Customer> databaseSet = new TreeSet<Customer>();
	Set<Transaction> transaction = new TreeSet<Transaction>();
	
	@Override
	public Customer createCustomer(Customer customer) throws CustomerExists {
		customer.setCustomerId(200);
		databaseSet.add(customer);
		return customer;
	}

	@Override
	public String withDraw(Customer customer, double amount)
			throws InsufficientBalanceException {
		return null;
	}

	@Override
	public String deposit(Customer customer, double amount)
			throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer checkUser(String username, String password)
			throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> printTransaction(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer isValidUser(String mobileNumber)
			throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double checkBalance(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

}
