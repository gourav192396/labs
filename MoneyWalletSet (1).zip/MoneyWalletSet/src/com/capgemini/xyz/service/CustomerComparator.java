package com.capgemini.xyz.service;

import java.util.Comparator;

import com.capgemini.xyz.bean.Customer;

public class CustomerComparator implements Comparator<Customer> {

	@Override
	public int compare(Customer o1, Customer o2) {
		return (int) (o1.getBalance()-o2.getBalance());
	}

}
